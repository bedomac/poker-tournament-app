'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import BettingControls from './betting-controls'

interface Player {
  id: string
  name: string
  chips: number
  cards: string[]
  isDealer: boolean
  isSmallBlind: boolean
  isBigBlind: boolean
  isActive: boolean
  hasFolded: boolean
  bet: number
  currentBet: number
}

interface PokerTableProps {
  players: Player[]
  pot: number
  communityCards: string[]
  currentPlayerId: string
  onPlayerAction: (action: string, amount?: number) => void
  currentBet: number
  minRaise: number
}

export default function PokerTable({
  players,
  pot,
  communityCards,
  currentPlayerId,
  onPlayerAction,
  currentBet,
  minRaise
}: PokerTableProps) {
  // Seat positions around the table (9-seat table)
  const seatPositions = [
    { top: '10%', left: '50%', transform: 'translate(-50%, -50%)' }, // Top (seat 1)
    { top: '20%', left: '80%', transform: 'translate(-50%, -50%)' }, // Top-right (seat 2)
    { top: '50%', left: '90%', transform: 'translate(-50%, -50%)' }, // Right (seat 3)
    { top: '80%', left: '80%', transform: 'translate(-50%, -50%)' }, // Bottom-right (seat 4)
    { top: '90%', left: '50%', transform: 'translate(-50%, -50%)' }, // Bottom (seat 5)
    { top: '80%', left: '20%', transform: 'translate(-50%, -50%)' }, // Bottom-left (seat 6)
    { top: '50%', left: '10%', transform: 'translate(-50%, -50%)' }, // Left (seat 7)
    { top: '20%', left: '20%', transform: 'translate(-50%, -50%)' }, // Top-left (seat 8)
    { top: '35%', left: '50%', transform: 'translate(-50%, -50%)' }  // Top-center (seat 9)
  ]

  const renderCard = (card: string, hidden = false) => {
    if (hidden) {
      return (
        <div className="w-12 h-16 bg-gradient-to-br from-blue-600 to-blue-800 rounded-md border-2 border-white shadow-lg flex items-center justify-center">
          <div className="w-8 h-10 bg-blue-400 rounded-sm"></div>
        </div>
      )
    }

    const suit = card.slice(-1)
    const rank = card.slice(0, -1)
    const suitSymbols = { 'h': '♥', 'd': '♦', 'c': '♣', 's': '♠' }
    const suitColors = { 'h': 'text-red-600', 'd': 'text-red-600', 'c': 'text-black', 's': 'text-black' }

    return (
      <div className="w-12 h-16 bg-white rounded-md border border-gray-300 shadow-lg flex flex-col items-center justify-center">
        <div className={`text-lg font-bold ${suitColors[suit as keyof typeof suitColors]}`}>
          {rank}
        </div>
        <div className={`text-xl ${suitColors[suit as keyof typeof suitColors]}`}>
          {suitSymbols[suit as keyof typeof suitSymbols]}
        </div>
      </div>
    )
  }

  const renderChips = (amount: number) => {
    if (amount === 0) return null
    
    const chipColors = [
      { color: 'bg-green-500', value: 25 },
      { color: 'bg-red-500', value: 100 },
      { color: 'bg-blue-500', value: 500 },
      { color: 'bg-purple-500', value: 1000 }
    ]

    return (
      <div className="flex items-center gap-1">
        {chipColors.map((chip, index) => {
          const count = Math.floor(amount / chip.value)
          if (count > 0) {
            return (
              <div key={index} className="flex -space-x-1">
                {[...Array(Math.min(count, 3))].map((_, i) => (
                  <div
                    key={i}
                    className={`w-4 h-4 ${chip.color} rounded-full border border-white`}
                  />
                ))}
              </div>
            )
          }
          return null
        })}
      </div>
    )
  }

  const currentPlayer = players.find(p => p.id === currentPlayerId)
  const callAmount = currentBet - (currentPlayer?.currentBet || 0)
  const canCheck = callAmount === 0
  const canCall = callAmount > 0 && (currentPlayer?.chips || 0) >= callAmount
  const canRaise = (currentPlayer?.chips || 0) > callAmount

  return (
    <div className="relative w-full max-w-4xl mx-auto p-4">
      {/* Poker Table */}
      <div className="relative w-full h-96 bg-gradient-to-br from-green-700 to-green-900 rounded-full border-8 border-yellow-800 shadow-2xl">
        {/* Table center pattern */}
        <div className="absolute inset-8 rounded-full border-2 border-yellow-600 opacity-50"></div>
        
        {/* Pot display */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
          <Card className="bg-yellow-100 border-yellow-400">
            <CardContent className="p-3 text-center">
              <div className="text-sm font-semibold text-yellow-800">POT</div>
              <div className="text-lg font-bold text-yellow-900">${pot.toLocaleString()}</div>
            </CardContent>
          </Card>
        </div>

        {/* Community Cards */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-8">
          <div className="flex gap-2">
            {communityCards.map((card, index) => (
              <div key={index}>
                {renderCard(card)}
              </div>
            ))}
            {communityCards.length < 5 && (
              [...Array(5 - communityCards.length)].map((_, index) => (
                <div key={index} className="w-12 h-16 bg-gray-300 rounded-md border-2 border-dashed border-gray-400 opacity-50"></div>
              ))
            )}
          </div>
        </div>

        {/* Player Seats */}
        {players.map((player, index) => {
          const position = seatPositions[index % seatPositions.length]
          const isCurrentPlayer = player.id === currentPlayerId
          
          return (
            <div
              key={player.id}
              className={`absolute ${position.top} ${position.left} ${position.transform} transition-all duration-300 ${
                isCurrentPlayer ? 'z-10 scale-110' : 'z-0'
              }`}
            >
              <Card className={`w-32 ${isCurrentPlayer ? 'ring-4 ring-yellow-400' : ''} ${player.isActive ? 'bg-blue-50' : 'bg-gray-50'}`}>
                <CardContent className="p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="text-xs">
                        {player.name.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold truncate">{player.name}</div>
                      <div className="text-xs text-gray-600">${player.chips.toLocaleString()}</div>
                    </div>
                  </div>
                  
                  {/* Player indicators */}
                  <div className="flex gap-1 mb-2">
                    {player.isDealer && (
                      <Badge variant="secondary" className="text-xs px-1 py-0">
                        D
                      </Badge>
                    )}
                    {player.isSmallBlind && (
                      <Badge variant="outline" className="text-xs px-1 py-0">
                        SB
                      </Badge>
                    )}
                    {player.isBigBlind && (
                      <Badge variant="outline" className="text-xs px-1 py-0">
                        BB
                      </Badge>
                    )}
                    {player.hasFolded && (
                      <Badge variant="destructive" className="text-xs px-1 py-0">
                        FOLD
                      </Badge>
                    )}
                  </div>

                  {/* Player Cards */}
                  <div className="flex gap-1 justify-center">
                    {player.cards.map((card, cardIndex) => (
                      <div key={cardIndex}>
                        {renderCard(card, !isCurrentPlayer && player.cards.length > 0)}
                      </div>
                    ))}
                  </div>

                  {/* Player Bet */}
                  {player.currentBet > 0 && (
                    <div className="mt-2 text-center">
                      <div className="text-xs font-semibold text-blue-600">Bet: ${player.currentBet}</div>
                    </div>
                  )}

                  {/* Chips */}
                  <div className="mt-2 flex justify-center">
                    {renderChips(player.chips)}
                  </div>
                </CardContent>
              </Card>
            </div>
          )
        })}
      </div>

      {/* Betting Controls */}
      {currentPlayer && !currentPlayer.hasFolded && (
        <div className="mt-8">
          <BettingControls
            playerId={currentPlayerId}
            playerChips={currentPlayer.chips}
            currentBet={currentBet}
            playerBet={currentPlayer.currentBet}
            minRaise={minRaise}
            pot={pot}
            onAction={onPlayerAction}
            isPlayerTurn={true}
            canCheck={canCheck}
            canCall={canCall}
            canRaise={canRaise}
            callAmount={callAmount}
          />
        </div>
      )}
    </div>
  )
}