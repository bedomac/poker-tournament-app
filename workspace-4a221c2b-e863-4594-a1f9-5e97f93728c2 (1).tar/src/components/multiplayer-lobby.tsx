'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { usePokerSocket } from '@/hooks/use-poker-socket'
import PokerTable from './poker-table'

interface Player {
  id: string
  name: string
  chips: number
  cards: string[]
  isDealer: boolean
  isSmallBlind: boolean
  isBigBlind: boolean
  isActive: boolean
  hasFolded: boolean
  hasActed: boolean
  bet: number
  currentBet: number
}

export default function MultiplayerLobby() {
  const [playerName, setPlayerName] = useState('')
  const [roomId, setRoomId] = useState('')
  const [showJoinDialog, setShowJoinDialog] = useState(false)
  const [showCreateDialog, setShowCreateDialog] = useState(false)

  const {
    isConnected,
    currentRoom,
    playerId,
    gameState,
    tournaments,
    error,
    joinTournament,
    leaveTournament,
    startTournament,
    playerAction,
    startNewHand,
    getTournaments,
    clearError
  } = usePokerSocket()

  useEffect(() => {
    if (isConnected) {
      getTournaments()
      // Refresh tournaments list every 5 seconds
      const interval = setInterval(getTournaments, 5000)
      return () => clearInterval(interval)
    }
  }, [isConnected, getTournaments])

  const handleJoinTournament = () => {
    if (playerName.trim() && roomId.trim()) {
      joinTournament(roomId.trim(), playerName.trim())
      setShowJoinDialog(false)
    }
  }

  const handleCreateTournament = () => {
    const newRoomId = Math.random().toString(36).substr(2, 9).toUpperCase()
    setRoomId(newRoomId)
    setShowCreateDialog(false)
    setShowJoinDialog(true)
  }

  const handlePlayerAction = (action: string, amount?: number) => {
    if (currentRoom) {
      playerAction(currentRoom, action, amount)
    }
  }

  const handleStartNewHand = () => {
    if (currentRoom) {
      startNewHand(currentRoom)
    }
  }

  const handleLeaveTournament = () => {
    if (currentRoom) {
      leaveTournament(currentRoom)
    }
  }

  const handleStartTournament = () => {
    if (currentRoom) {
      startTournament(currentRoom)
    }
  }

  if (!isConnected) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-96">
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Connecting to poker server...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (currentRoom && gameState) {
    const currentPlayer = gameState.players.find(p => p.id === playerId)
    const isCurrentPlayerTurn = gameState.currentPlayerIndex < gameState.players.length && 
                               gameState.players[gameState.currentPlayerIndex]?.id === playerId

    return (
      <div className="min-h-screen bg-gradient-to-br from-green-900 to-green-700">
        {/* Header */}
        <div className="w-full max-w-4xl mx-auto p-4 pt-8">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h1 className="text-2xl font-bold text-white">Room: {currentRoom}</h1>
              <p className="text-green-200">Multiplayer Texas Hold'em</p>
            </div>
            <div className="flex gap-2">
              {!gameState.isGameOver && currentPlayer && !currentPlayer.hasFolded && isCurrentPlayerTurn && (
                <Button
                  onClick={handleStartTournament}
                  className="bg-green-600 hover:bg-green-700 text-white"
                  disabled={gameState.bettingRound !== 'showdown'}
                >
                  Start Game
                </Button>
              )}
              <Button 
                onClick={handleLeaveTournament}
                variant="outline"
                className="text-white border-white hover:bg-white hover:text-green-900"
              >
                Leave Room
              </Button>
            </div>
          </div>

          {/* Error display */}
          {error && (
            <Card className="mb-4 border-red-200 bg-red-50">
              <CardContent className="p-3">
                <div className="text-red-700 text-sm">{error}</div>
                <Button size="sm" onClick={clearError} className="mt-2">
                  Dismiss
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Poker Table */}
          <PokerTable
            players={gameState.players}
            pot={gameState.pot}
            communityCards={gameState.communityCards}
            currentPlayerId={playerId || ''}
            onPlayerAction={handlePlayerAction}
            currentBet={gameState.currentBet}
            minRaise={gameState.minimumRaise}
          />

          {/* Game Controls */}
          {gameState.isGameOver && (
            <Card className="mt-4 border-yellow-200 bg-yellow-50">
              <CardContent className="p-4">
                <div className="text-center">
                  <div className="font-semibold text-yellow-800 mb-2">Hand Complete!</div>
                  <div className="text-sm text-yellow-700 mb-3">
                    Winners: {gameState.winners.map(w => gameState.players.find(p => p.id === w)?.name).join(', ')}
                  </div>
                  <Button 
                    onClick={handleStartNewHand}
                    className="bg-yellow-600 hover:bg-yellow-700 text-white"
                  >
                    Deal New Hand
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Game Info */}
          <Card className="mt-4 bg-white/10 backdrop-blur-sm">
            <CardContent className="p-4 text-white">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div>
                  <span className="text-green-200">Blinds:</span> {gameState.smallBlindAmount}/{gameState.bigBlindAmount}
                </div>
                <div>
                  <span className="text-green-200">Round:</span> {gameState.bettingRound}
                </div>
                <div>
                  <span className="text-green-200">Players:</span> {gameState.players.filter(p => !p.hasFolded).length}/{gameState.players.length}
                </div>
                <div>
                  <span className="text-green-200">Min Raise:</span> {gameState.minimumRaise}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Multiplayer Poker Tournament</h1>
          <p className="text-gray-600">Join or create a Texas Hold'em tournament</p>
          <div className="flex justify-center gap-4 mt-4">
            <Dialog open={showJoinDialog} onOpenChange={setShowJoinDialog}>
              <DialogTrigger asChild>
                <Button className="bg-green-600 hover:bg-green-700 text-white">
                  Join Tournament
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Join Tournament</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Your Name</label>
                    <Input
                      value={playerName}
                      onChange={(e) => setPlayerName(e.target.value)}
                      placeholder="Enter your name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Room ID</label>
                    <Input
                      value={roomId}
                      onChange={(e) => setRoomId(e.target.value.toUpperCase())}
                      placeholder="Enter room ID"
                      maxLength={9}
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleJoinTournament} disabled={!playerName.trim() || !roomId.trim()}>
                      Join
                    </Button>
                    <Button variant="outline" onClick={() => setShowJoinDialog(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                  Create Tournament
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Tournament</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Your Name</label>
                    <Input
                      value={playerName}
                      onChange={(e) => setPlayerName(e.target.value)}
                      placeholder="Enter your name"
                    />
                  </div>
                  <div className="text-sm text-gray-600">
                    A new room ID will be generated for you.
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleCreateTournament} disabled={!playerName.trim()}>
                      Create
                    </Button>
                    <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Error display */}
        {error && (
          <Card className="mb-6 border-red-200 bg-red-50">
            <CardContent className="p-4">
              <div className="text-red-700">{error}</div>
              <Button size="sm" onClick={clearError} className="mt-2">
                Dismiss
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Active Tournaments */}
        <Card>
          <CardHeader>
            <CardTitle>Active Tournaments</CardTitle>
          </CardHeader>
          <CardContent>
            {tournaments.length === 0 ? (
              <div className="text-center text-gray-500 py-8">
                No active tournaments. Create one to get started!
              </div>
            ) : (
              <div className="space-y-3">
                {tournaments.map((tournament) => (
                  <div key={tournament.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <div className="font-semibold">{tournament.name}</div>
                      <div className="text-sm text-gray-600">Room: {tournament.id}</div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-sm">
                        <span className="font-medium">{tournament.players}</span>/{tournament.maxPlayers} players
                      </div>
                      <Badge variant={tournament.isStarted ? "destructive" : "secondary"}>
                        {tournament.isStarted ? "In Progress" : "Waiting"}
                      </Badge>
                      <Button
                        size="sm"
                        onClick={() => {
                          setRoomId(tournament.id)
                          setShowJoinDialog(true)
                        }}
                        disabled={tournament.players >= tournament.maxPlayers || tournament.isStarted}
                      >
                        {tournament.players >= tournament.maxPlayers ? "Full" : tournament.isStarted ? "Started" : "Join"}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}