'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Slider } from '@/components/ui/slider'

interface BettingControlsProps {
  playerId: string
  playerChips: number
  currentBet: number
  playerBet: number
  minRaise: number
  pot: number
  onAction: (action: 'fold' | 'check' | 'call' | 'raise' | 'allin', amount?: number) => void
  isPlayerTurn: boolean
  canCheck: boolean
  canCall: boolean
  canRaise: boolean
  callAmount: number
}

export default function BettingControls({
  playerId,
  playerChips,
  currentBet,
  playerBet,
  minRaise,
  pot,
  onAction,
  isPlayerTurn,
  canCheck,
  canCall,
  canRaise,
  callAmount
}: BettingControlsProps) {
  const [raiseAmount, setRaiseAmount] = useState(minRaise)
  const [showRaiseSlider, setShowRaiseSlider] = useState(false)

  const handleFold = () => onAction('fold')
  const handleCheck = () => onAction('check')
  const handleCall = () => onAction('call')
  const handleAllIn = () => onAction('allin')
  const handleRaise = () => {
    if (raiseAmount >= minRaise && raiseAmount <= playerChips) {
      onAction('raise', raiseAmount)
      setShowRaiseSlider(false)
    }
  }

  const maxRaise = playerChips
  const totalBet = playerBet + raiseAmount

  // Quick raise amounts (percentages of pot)
  const quickRaises = [
    { label: 'Pot', amount: pot },
    { label: '1/2 Pot', amount: Math.floor(pot / 2) },
    { label: '2/3 Pot', amount: Math.floor(pot * 2 / 3) },
    { label: '3/4 Pot', amount: Math.floor(pot * 3 / 4) }
  ]

  const handleQuickRaise = (amount: number) => {
    const adjustedAmount = Math.max(minRaise, Math.min(amount, maxRaise))
    setRaiseAmount(adjustedAmount)
  }

  if (!isPlayerTurn) {
    return (
      <Card className="bg-gray-100">
        <CardContent className="p-4">
          <div className="text-center text-gray-600">
            Waiting for other players...
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-2 border-yellow-400 bg-yellow-50">
      <CardContent className="p-4">
        <div className="space-y-4">
          {/* Player Info */}
          <div className="flex justify-between items-center">
            <div>
              <span className="font-semibold">Your Stack: </span>
              <Badge variant="outline" className="ml-2">
                ${playerChips.toLocaleString()}
              </Badge>
            </div>
            <div>
              <span className="font-semibold">To Call: </span>
              <Badge variant="outline" className="ml-2">
                ${callAmount.toLocaleString()}
              </Badge>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
            {/* Fold */}
            <Button
              onClick={handleFold}
              variant="destructive"
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              Fold
            </Button>

            {/* Check/Call */}
            {canCheck ? (
              <Button
                onClick={handleCheck}
                variant="outline"
                className="bg-blue-100 hover:bg-blue-200 text-blue-700 border-blue-300"
              >
                Check
              </Button>
            ) : (
              <Button
                onClick={handleCall}
                variant="outline"
                className="bg-green-100 hover:bg-green-200 text-green-700 border-green-300"
                disabled={!canCall}
              >
                Call ${callAmount}
              </Button>
            )}

            {/* Raise */}
            <Button
              onClick={() => setShowRaiseSlider(!showRaiseSlider)}
              variant="outline"
              className="bg-yellow-100 hover:bg-yellow-200 text-yellow-700 border-yellow-300"
              disabled={!canRaise}
            >
              Raise
            </Button>

            {/* All In */}
            <Button
              onClick={handleAllIn}
              variant="outline"
              className="bg-purple-100 hover:bg-purple-200 text-purple-700 border-purple-300"
            >
              All In
            </Button>
          </div>

          {/* Raise Controls */}
          {showRaiseSlider && canRaise && (
            <div className="space-y-3 pt-3 border-t">
              <div className="text-sm font-medium">
                Raise Amount: ${raiseAmount.toLocaleString()} 
                (Total: ${totalBet.toLocaleString()})
              </div>
              
              {/* Quick Raise Buttons */}
              <div className="flex flex-wrap gap-2">
                {quickRaises.map((quickRaise, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleQuickRaise(quickRaise.amount)}
                    className="text-xs"
                  >
                    {quickRaise.label}
                  </Button>
                ))}
              </div>

              {/* Raise Slider */}
              <div className="space-y-2">
                <Slider
                  value={[raiseAmount]}
                  onValueChange={(value) => setRaiseAmount(value[0])}
                  max={maxRaise}
                  min={minRaise}
                  step={minRaise}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-gray-600">
                  <span>Min: ${minRaise.toLocaleString()}</span>
                  <span>Max: ${maxRaise.toLocaleString()}</span>
                </div>
              </div>

              {/* Manual Input */}
              <div className="flex gap-2">
                <Input
                  type="number"
                  value={raiseAmount}
                  onChange={(e) => setRaiseAmount(Number(e.target.value))}
                  min={minRaise}
                  max={maxRaise}
                  className="w-32"
                />
                <Button
                  onClick={handleRaise}
                  className="bg-yellow-600 hover:bg-yellow-700 text-white"
                  disabled={raiseAmount < minRaise || raiseAmount > maxRaise}
                >
                  Confirm Raise
                </Button>
              </div>
            </div>
          )}

          {/* Betting Info */}
          <div className="text-xs text-gray-600 space-y-1">
            <div>Current Bet: ${currentBet.toLocaleString()}</div>
            <div>Your Bet: ${playerBet.toLocaleString()}</div>
            <div>Pot: ${pot.toLocaleString()}</div>
            <div>Min Raise: ${minRaise.toLocaleString()}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}