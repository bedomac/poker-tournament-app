'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import PlayerManagement from './player-management'

interface TournamentSettings {
  name: string
  maxPlayers: number
  startingChips: number
  blindLevels: Array<{
    smallBlind: number
    bigBlind: number
    ante: number
    duration: number
  }>
  prizeDistribution: number[]
}

interface Player {
  id: string
  name: string
  chips: number
  cards: any[]
  isDealer: boolean
  isSmallBlind: boolean
  isBigBlind: boolean
  isActive: boolean
  hasFolded: boolean
  hasActed: boolean
  bet: number
  currentBet: number
}

interface TournamentLobbyProps {
  players: Player[]
  tournamentSettings: TournamentSettings
  onStartTournament: () => void
  onAddPlayer: (name: string, buyIn: number) => void
  onRemovePlayer: (playerId: string) => void
  onPlayerRebuy: (playerId: string, amount: number) => void
  onUpdateSettings: (settings: TournamentSettings) => void
  isTournamentActive: boolean
}

export default function TournamentLobby({
  players,
  tournamentSettings,
  onStartTournament,
  onAddPlayer,
  onRemovePlayer,
  onPlayerRebuy,
  onUpdateSettings,
  isTournamentActive
}: TournamentLobbyProps) {
  const [settings, setSettings] = useState<TournamentSettings>(tournamentSettings)

  const handleSettingsUpdate = (newSettings: Partial<TournamentSettings>) => {
    const updated = { ...settings, ...newSettings }
    setSettings(updated)
    onUpdateSettings(updated)
  }

  const canStartTournament = players.length >= 2 && !isTournamentActive

  const generateBlindLevels = (startingSmallBlind: number, levels: number = 10) => {
    const levelsArray = []
    let smallBlind = startingSmallBlind
    
    for (let i = 0; i < levels; i++) {
      levelsArray.push({
        smallBlind,
        bigBlind: smallBlind * 2,
        ante: Math.floor(smallBlind / 4),
        duration: 15 // 15 minutes per level
      })
      smallBlind = i % 2 === 0 ? smallBlind * 1.5 : smallBlind * 2
    }
    
    return levelsArray
  }

  const getDefaultPrizeDistribution = (playerCount: number) => {
    if (playerCount <= 3) return [70, 30, 0]
    if (playerCount <= 5) return [50, 30, 20, 0, 0]
    if (playerCount <= 8) return [40, 25, 15, 12, 8]
    return [35, 20, 15, 12, 10, 8]
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Tournament Lobby</h1>
        <p className="text-gray-600">Set up and manage your Texas Hold'em tournament</p>
      </div>

      <Tabs defaultValue="players" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="players">Players</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="structure">Structure</TabsTrigger>
        </TabsList>

        <TabsContent value="players">
          <PlayerManagement
            players={players}
            maxPlayers={settings.maxPlayers}
            onAddPlayer={onAddPlayer}
            onRemovePlayer={onRemovePlayer}
            onPlayerRebuy={onPlayerRebuy}
            isGameActive={isTournamentActive}
          />
        </TabsContent>

        <TabsContent value="settings">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Tournament Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="tournamentName">Tournament Name</Label>
                  <Input
                    id="tournamentName"
                    value={settings.name}
                    onChange={(e) => handleSettingsUpdate({ name: e.target.value })}
                    placeholder="My Poker Tournament"
                  />
                </div>
                
                <div>
                  <Label htmlFor="maxPlayers">Maximum Players</Label>
                  <Input
                    id="maxPlayers"
                    type="number"
                    min="2"
                    max="9"
                    value={settings.maxPlayers}
                    onChange={(e) => handleSettingsUpdate({ maxPlayers: Number(e.target.value) })}
                  />
                </div>

                <div>
                  <Label htmlFor="startingChips">Starting Chips</Label>
                  <Input
                    id="startingChips"
                    type="number"
                    min="100"
                    step="100"
                    value={settings.startingChips}
                    onChange={(e) => handleSettingsUpdate({ startingChips: Number(e.target.value) })}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Prize Distribution</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-sm text-gray-600 mb-4">
                  Prize pool distribution by finishing position
                </div>
                
                {settings.prizeDistribution.slice(0, 5).map((percentage, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm font-medium">
                      {index + 1}{['st', 'nd', 'rd', 'th', 'th'][index]} Place
                    </span>
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        value={percentage}
                        onChange={(e) => {
                          const newDistribution = [...settings.prizeDistribution]
                          newDistribution[index] = Number(e.target.value)
                          handleSettingsUpdate({ prizeDistribution: newDistribution })
                        }}
                        className="w-20"
                        disabled={index >= players.length}
                      />
                      <span className="text-sm text-gray-600">%</span>
                    </div>
                  </div>
                ))}
                
                <Button
                  variant="outline"
                  onClick={() => handleSettingsUpdate({ 
                    prizeDistribution: getDefaultPrizeDistribution(players.length) 
                  })}
                  className="w-full"
                >
                  Auto-distribute for {players.length} players
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="structure">
          <Card>
            <CardHeader>
              <CardTitle>Blind Structure</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-5 gap-4 text-sm font-semibold text-gray-700 border-b pb-2">
                  <div>Level</div>
                  <div>Small Blind</div>
                  <div>Big Blind</div>
                  <div>Ante</div>
                  <div>Duration</div>
                </div>
                
                {settings.blindLevels.map((level, index) => (
                  <div key={index} className="grid grid-cols-5 gap-4 text-sm py-2 border-b">
                    <div>{index + 1}</div>
                    <div>${level.smallBlind}</div>
                    <div>${level.bigBlind}</div>
                    <div>${level.ante}</div>
                    <div>{level.duration} min</div>
                  </div>
                ))}
                
                <Button
                  variant="outline"
                  onClick={() => handleSettingsUpdate({ 
                    blindLevels: generateBlindLevels(25) 
                  })}
                  className="w-full"
                >
                  Generate Standard Structure
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Start Tournament Button */}
      {canStartTournament && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="text-lg font-semibold text-green-800">
                Ready to Start Tournament!
              </div>
              <div className="text-sm text-green-700">
                {players.length} players have joined. All players will start with {settings.startingChips} chips.
              </div>
              <Button 
                onClick={onStartTournament}
                className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg"
              >
                Start Tournament
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tournament Active Notice */}
      {isTournamentActive && (
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="pt-6">
            <div className="text-center">
              <Badge variant="secondary" className="text-lg px-4 py-2 mb-2">
                Tournament in Progress
              </Badge>
              <p className="text-blue-700">
                {settings.name} is currently running with {players.length} players
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}