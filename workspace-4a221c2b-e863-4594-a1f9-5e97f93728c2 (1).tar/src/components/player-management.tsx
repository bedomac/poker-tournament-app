'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'

interface Player {
  id: string
  name: string
  chips: number
  cards: any[]
  isDealer: boolean
  isSmallBlind: boolean
  isBigBlind: boolean
  isActive: boolean
  hasFolded: boolean
  hasActed: boolean
  bet: number
  currentBet: number
}

interface PlayerManagementProps {
  players: Player[]
  maxPlayers: number
  onAddPlayer: (name: string, buyIn: number) => void
  onRemovePlayer: (playerId: string) => void
  onPlayerRebuy: (playerId: string, amount: number) => void
  isGameActive: boolean
}

export default function PlayerManagement({
  players,
  maxPlayers,
  onAddPlayer,
  onRemovePlayer,
  onPlayerRebuy,
  isGameActive
}: PlayerManagementProps) {
  const [newPlayerName, setNewPlayerName] = useState('')
  const [buyInAmount, setBuyInAmount] = useState(1500)
  const [rebuyAmount, setRebuyAmount] = useState(1000)
  const [selectedPlayerForRebuy, setSelectedPlayerForRebuy] = useState<string | null>(null)

  const handleAddPlayer = () => {
    if (newPlayerName.trim() && buyInAmount > 0 && players.length < maxPlayers) {
      onAddPlayer(newPlayerName.trim(), buyInAmount)
      setNewPlayerName('')
    }
  }

  const handleRebuy = () => {
    if (selectedPlayerForRebuy && rebuyAmount > 0) {
      onPlayerRebuy(selectedPlayerForRebuy, rebuyAmount)
      setSelectedPlayerForRebuy(null)
    }
  }

  const availableSeats = maxPlayers - players.length

  return (
    <div className="space-y-4">
      {/* Add Player Section */}
      {availableSeats > 0 && !isGameActive && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Add Player</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="Player name"
                value={newPlayerName}
                onChange={(e) => setNewPlayerName(e.target.value)}
                className="flex-1"
              />
              <Input
                type="number"
                placeholder="Buy-in"
                value={buyInAmount}
                onChange={(e) => setBuyInAmount(Number(e.target.value))}
                className="w-32"
                min="100"
                step="100"
              />
              <Button onClick={handleAddPlayer} disabled={!newPlayerName.trim() || buyInAmount <= 0}>
                Join
              </Button>
            </div>
            <div className="text-sm text-gray-600">
              Available seats: {availableSeats}/{maxPlayers}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Players List */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Players at Table</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {players.map((player) => (
              <div key={player.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Avatar className="w-10 h-10">
                    <AvatarFallback className="text-sm">
                      {player.name.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-semibold">{player.name}</div>
                    <div className="text-sm text-gray-600">
                      Stack: ${player.chips.toLocaleString()}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    {player.isDealer && (
                      <Badge variant="secondary" className="text-xs">D</Badge>
                    )}
                    {player.isSmallBlind && (
                      <Badge variant="outline" className="text-xs">SB</Badge>
                    )}
                    {player.isBigBlind && (
                      <Badge variant="outline" className="text-xs">BB</Badge>
                    )}
                    {player.hasFolded && (
                      <Badge variant="destructive" className="text-xs">Folded</Badge>
                    )}
                  </div>
                </div>
                
                <div className="flex gap-2">
                  {/* Rebuy Button */}
                  {player.chips < 500 && !isGameActive && (
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => setSelectedPlayerForRebuy(player.id)}
                        >
                          Rebuy
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Rebuy for {player.name}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <Input
                            type="number"
                            placeholder="Rebuy amount"
                            value={rebuyAmount}
                            onChange={(e) => setRebuyAmount(Number(e.target.value))}
                            min="100"
                            step="100"
                          />
                          <div className="flex gap-2">
                            <Button onClick={handleRebuy} disabled={rebuyAmount <= 0}>
                              Confirm Rebuy
                            </Button>
                            <Button variant="outline" onClick={() => setSelectedPlayerForRebuy(null)}>
                              Cancel
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  )}
                  
                  {/* Remove Button */}
                  {!isGameActive && (
                    <Button 
                      variant="destructive" 
                      size="sm"
                      onClick={() => onRemovePlayer(player.id)}
                    >
                      Leave
                    </Button>
                  )}
                </div>
              </div>
            ))}
            
            {players.length === 0 && (
              <div className="text-center text-gray-500 py-8">
                No players at the table. Add players to start the game.
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Game Controls */}
      {players.length >= 2 && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <div className="mb-4">
                <Badge variant="outline" className="text-lg px-4 py-2">
                  {players.length} players ready
                </Badge>
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Minimum 2 players required to start the game
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}