'use client'

import { useEffect, useRef, useState } from 'react'
import { io, Socket } from 'socket.io-client'

interface Player {
  id: string
  name: string
  chips: number
  cards: string[]
  isDealer: boolean
  isSmallBlind: boolean
  isBigBlind: boolean
  isActive: boolean
  hasFolded: boolean
  hasActed: boolean
  bet: number
  currentBet: number
}

interface GameState {
  players: Player[]
  communityCards: string[]
  pot: number
  sidePots: any[]
  currentPlayerIndex: number
  dealerIndex: number
  smallBlindIndex: number
  bigBlindIndex: number
  bettingRound: 'preflop' | 'flop' | 'turn' | 'river' | 'showdown'
  smallBlindAmount: number
  bigBlindAmount: number
  minimumRaise: number
  currentBet: number
  lastRaise: number
  isGameOver: boolean
  winners: string[]
}

interface TournamentInfo {
  id: string
  name: string
  players: number
  maxPlayers: number
  isStarted: boolean
}

export function usePokerSocket() {
  const socketRef = useRef<Socket | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [currentRoom, setCurrentRoom] = useState<string | null>(null)
  const [playerId, setPlayerId] = useState<string | null>(null)
  const [gameState, setGameState] = useState<GameState | null>(null)
  const [tournaments, setTournaments] = useState<TournamentInfo[]>([])
  const [error, setError] = useState<string | null>(null)

  // Initialize socket connection
  useEffect(() => {
    const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:3001')
    socketRef.current = socket

    socket.on('connect', () => {
      setIsConnected(true)
      setError(null)
    })

    socket.on('disconnect', () => {
      setIsConnected(false)
    })

    // Tournament events
    socket.on('join-success', (data: { roomId: string; playerId: string; players: Player[] }) => {
      setCurrentRoom(data.roomId)
      setPlayerId(data.playerId)
      setError(null)
    })

    socket.on('join-error', (data: { message: string }) => {
      setError(data.message)
    })

    socket.on('leave-success', () => {
      setCurrentRoom(null)
      setPlayerId(null)
      setGameState(null)
      setError(null)
    })

    socket.on('player-joined', (data: { player: Player; players: Player[] }) => {
      if (gameState) {
        setGameState(prev => prev ? { ...prev, players: data.players } : null)
      }
    })

    socket.on('player-left', (data: { playerId: string; players: Player[] }) => {
      if (gameState) {
        setGameState(prev => prev ? { ...prev, players: data.players } : null)
      }
    })

    socket.on('tournament-started', (data: { gameState: GameState }) => {
      setGameState(data.gameState)
      setError(null)
    })

    socket.on('start-error', (data: { message: string }) => {
      setError(data.message)
    })

    socket.on('game-state-updated', (data: { gameState: GameState }) => {
      setGameState(data.gameState)
    })

    socket.on('hand-complete', (data: { winners: string[]; gameState: GameState }) => {
      setGameState(data.gameState)
    })

    socket.on('new-hand-started', (data: { gameState: GameState }) => {
      setGameState(data.gameState)
    })

    socket.on('action-error', (data: { message: string }) => {
      setError(data.message)
    })

    socket.on('tournaments-list', (data: { tournaments: TournamentInfo[] }) => {
      setTournaments(data.tournaments)
    })

    return () => {
      socket.disconnect()
    }
  }, [])

  // Join tournament
  const joinTournament = (roomId: string, playerName: string) => {
    if (socketRef.current) {
      socketRef.current.emit('join-tournament', { roomId, playerName })
    }
  }

  // Leave tournament
  const leaveTournament = (roomId: string) => {
    if (socketRef.current) {
      socketRef.current.emit('leave-tournament', { roomId })
    }
  }

  // Start tournament
  const startTournament = (roomId: string) => {
    if (socketRef.current) {
      socketRef.current.emit('start-tournament', { roomId })
    }
  }

  // Player action
  const playerAction = (roomId: string, action: string, amount?: number) => {
    if (socketRef.current) {
      socketRef.current.emit('player-action', { roomId, action, amount })
    }
  }

  // Start new hand
  const startNewHand = (roomId: string) => {
    if (socketRef.current) {
      socketRef.current.emit('start-new-hand', { roomId })
    }
  }

  // Get tournaments list
  const getTournaments = () => {
    if (socketRef.current) {
      socketRef.current.emit('get-tournaments')
    }
  }

  // Clear error
  const clearError = () => {
    setError(null)
  }

  return {
    isConnected,
    currentRoom,
    playerId,
    gameState,
    tournaments,
    error,
    joinTournament,
    leaveTournament,
    startTournament,
    playerAction,
    startNewHand,
    getTournaments,
    clearError
  }
}