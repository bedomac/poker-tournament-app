'use client'

import MultiplayerLobby from '@/components/multiplayer-lobby'

export default function Home() {
  return <MultiplayerLobby />
}