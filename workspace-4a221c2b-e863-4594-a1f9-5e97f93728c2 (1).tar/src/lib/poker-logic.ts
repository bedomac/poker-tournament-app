// Poker card and game logic

export interface Card {
  suit: 'hearts' | 'diamonds' | 'clubs' | 'spades'
  rank: string
  value: number
}

export interface Player {
  id: string
  name: string
  chips: number
  cards: Card[]
  isDealer: boolean
  isSmallBlind: boolean
  isBigBlind: boolean
  isActive: boolean
  hasFolded: boolean
  hasActed: boolean
  bet: number
  currentBet: number
}

export interface SidePot {
  amount: number
  eligiblePlayers: string[]
}

export interface GameState {
  players: Player[]
  communityCards: Card[]
  pot: number
  sidePots: SidePot[]
  currentPlayerIndex: number
  dealerIndex: number
  smallBlindIndex: number
  bigBlindIndex: number
  bettingRound: 'preflop' | 'flop' | 'turn' | 'river' | 'showdown'
  smallBlindAmount: number
  bigBlindAmount: number
  minimumRaise: number
  currentBet: number
  lastRaise: number
  isGameOver: boolean
  winners: string[]
}

export class PokerGame {
  private deck: Card[] = []
  private gameState: GameState

  constructor(initialPlayers: Player[], smallBlind = 25, bigBlind = 50) {
    this.gameState = {
      players: initialPlayers,
      communityCards: [],
      pot: 0,
      sidePots: [],
      currentPlayerIndex: 0,
      dealerIndex: 0,
      smallBlindIndex: 1,
      bigBlindIndex: 2,
      bettingRound: 'preflop',
      smallBlindAmount: smallBlind,
      bigBlindAmount: bigBlind,
      minimumRaise: bigBlind * 2,
      currentBet: bigBlind,
      lastRaise: bigBlind,
      isGameOver: false,
      winners: []
    }
    this.initializeDeck()
  }

  private initializeDeck() {
    const suits: Card['suit'][] = ['hearts', 'diamonds', 'clubs', 'spades']
    const ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
    const values = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]

    this.deck = []
    for (const suit of suits) {
      for (let i = 0; i < ranks.length; i++) {
        this.deck.push({
          suit,
          rank: ranks[i],
          value: values[i]
        })
      }
    }
    this.shuffleDeck()
  }

  private shuffleDeck() {
    for (let i = this.deck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[this.deck[i], this.deck[j]] = [this.deck[j], this.deck[i]]
    }
  }

  private dealCard(): Card {
    return this.deck.pop()!
  }

  startNewHand() {
    // Reset for new hand
    this.initializeDeck()
    this.gameState.communityCards = []
    this.gameState.pot = 0
    this.gameState.sidePots = []
    this.gameState.bettingRound = 'preflop'
    this.gameState.currentBet = this.gameState.bigBlindAmount
    this.gameState.minimumRaise = this.gameState.bigBlindAmount * 2
    this.gameState.isGameOver = false
    this.gameState.winners = []

    // Reset players
    this.gameState.players.forEach(player => {
      player.cards = []
      player.hasFolded = false
      player.hasActed = false
      player.bet = 0
      player.currentBet = 0
    })

    // Move dealer button
    this.moveDealerButton()

    // Post blinds
    this.postBlinds()

    // Deal hole cards
    this.dealHoleCards()

    // Set first player to act (after big blind)
    this.setFirstPlayerToAct()
  }

  private moveDealerButton() {
    const activePlayers = this.gameState.players.filter(p => p.chips > 0)
    if (activePlayers.length < 2) return

    // Find current dealer position
    const currentDealer = this.gameState.players.findIndex(p => p.isDealer)
    
    // Find next active player
    let nextDealer = (currentDealer + 1) % this.gameState.players.length
    while (this.gameState.players[nextDealer].chips === 0) {
      nextDealer = (nextDealer + 1) % this.gameState.players.length
    }

    // Update dealer and blind positions
    this.gameState.players.forEach((p, i) => {
      p.isDealer = i === nextDealer
    })

    this.gameState.dealerIndex = nextDealer
    
    // Set small blind
    let smallBlindIndex = (nextDealer + 1) % this.gameState.players.length
    while (this.gameState.players[smallBlindIndex].chips === 0) {
      smallBlindIndex = (smallBlindIndex + 1) % this.gameState.players.length
    }
    
    // Set big blind
    let bigBlindIndex = (smallBlindIndex + 1) % this.gameState.players.length
    while (this.gameState.players[bigBlindIndex].chips === 0) {
      bigBlindIndex = (bigBlindIndex + 1) % this.gameState.players.length
    }

    this.gameState.players[smallBlindIndex].isSmallBlind = true
    this.gameState.players[bigBlindIndex].isBigBlind = true
    this.gameState.smallBlindIndex = smallBlindIndex
    this.gameState.bigBlindIndex = bigBlindIndex
  }

  private postBlinds() {
    const smallBlindPlayer = this.gameState.players[this.gameState.smallBlindIndex]
    const bigBlindPlayer = this.gameState.players[this.gameState.bigBlindIndex]

    // Post small blind
    const smallBlindAmount = Math.min(smallBlindPlayer.chips, this.gameState.smallBlindAmount)
    smallBlindPlayer.chips -= smallBlindAmount
    smallBlindPlayer.bet = smallBlindAmount
    smallBlindPlayer.currentBet = smallBlindAmount
    smallBlindPlayer.hasActed = true
    this.gameState.pot += smallBlindAmount

    // Post big blind
    const bigBlindAmount = Math.min(bigBlindPlayer.chips, this.gameState.bigBlindAmount)
    bigBlindPlayer.chips -= bigBlindAmount
    bigBlindPlayer.bet = bigBlindAmount
    bigBlindPlayer.currentBet = bigBlindAmount
    bigBlindPlayer.hasActed = true
    this.gameState.pot += bigBlindAmount
  }

  private dealHoleCards() {
    // Deal 2 cards to each active player
    for (let i = 0; i < 2; i++) {
      this.gameState.players.forEach(player => {
        if (player.chips > 0) {
          player.cards.push(this.dealCard())
        }
      })
    }
  }

  private setFirstPlayerToAct() {
    // First to act is after big blind
    let firstToAct = (this.gameState.bigBlindIndex + 1) % this.gameState.players.length
    while (this.gameState.players[firstToAct].chips === 0 || this.gameState.players[firstToAct].hasFolded) {
      firstToAct = (firstToAct + 1) % this.gameState.players.length
    }
    this.gameState.currentPlayerIndex = firstToAct
  }

  playerAction(playerId: string, action: 'fold' | 'check' | 'call' | 'raise' | 'allin', amount?: number) {
    const playerIndex = this.gameState.players.findIndex(p => p.id === playerId)
    if (playerIndex === -1 || playerIndex !== this.gameState.currentPlayerIndex) {
      throw new Error('Invalid player or not their turn')
    }

    const player = this.gameState.players[playerIndex]

    switch (action) {
      case 'fold':
        player.hasFolded = true
        player.hasActed = true
        break

      case 'check':
        if (this.gameState.currentBet > player.currentBet) {
          throw new Error('Cannot check when there is a bet to call')
        }
        player.hasActed = true
        break

      case 'call':
        const callAmount = Math.min(player.chips, this.gameState.currentBet - player.currentBet)
        player.chips -= callAmount
        player.bet += callAmount
        player.currentBet += callAmount
        player.hasActed = true
        this.gameState.pot += callAmount
        break

      case 'raise':
        const raiseAmount = amount || this.gameState.minimumRaise
        const totalBet = this.gameState.currentBet + raiseAmount
        const actualRaise = Math.min(player.chips, totalBet - player.currentBet)
        
        player.chips -= actualRaise
        player.bet += actualRaise
        player.currentBet += actualRaise
        player.hasActed = true
        this.gameState.pot += actualRaise
        this.gameState.currentBet = player.currentBet
        this.gameState.lastRaise = raiseAmount
        this.gameState.minimumRaise = raiseAmount
        break

      case 'allin':
        const allInAmount = player.chips
        player.chips = 0
        player.bet += allInAmount
        player.currentBet += allInAmount
        player.hasActed = true
        this.gameState.pot += allInAmount
        
        if (player.currentBet > this.gameState.currentBet) {
          this.gameState.currentBet = player.currentBet
          this.gameState.lastRaise = player.currentBet - this.gameState.currentBet
        }
        break
    }

    this.moveToNextPlayer()
  }

  private moveToNextPlayer() {
    const activePlayers = this.gameState.players.filter(p => !p.hasFolded && p.chips > 0)
    
    // Check if betting round is complete
    if (this.isBettingRoundComplete()) {
      this.nextBettingRound()
      return
    }

    // Find next player
    let nextPlayer = (this.gameState.currentPlayerIndex + 1) % this.gameState.players.length
    let attempts = 0
    
    while (attempts < this.gameState.players.length) {
      const player = this.gameState.players[nextPlayer]
      if (!player.hasFolded && player.chips > 0 && !player.hasActed) {
        this.gameState.currentPlayerIndex = nextPlayer
        return
      }
      nextPlayer = (nextPlayer + 1) % this.gameState.players.length
      attempts++
    }

    // If we get here, betting round should be complete
    this.nextBettingRound()
  }

  private isBettingRoundComplete(): boolean {
    const activePlayers = this.gameState.players.filter(p => !p.hasFolded && p.chips > 0)
    
    // All players must have acted
    const allActed = activePlayers.every(p => p.hasActed)
    
    // All active players must have equal bets
    const equalBets = activePlayers.every(p => p.currentBet === this.gameState.currentBet || p.chips === 0)
    
    return allActed && equalBets
  }

  private nextBettingRound() {
    // Handle side pots before moving to next round
    this.handleSidePots()
    
    // Reset for next betting round
    this.gameState.players.forEach(player => {
      player.hasActed = false
      player.currentBet = 0
    })
    this.gameState.currentBet = 0

    switch (this.gameState.bettingRound) {
      case 'preflop':
        // Deal flop
        this.gameState.communityCards.push(this.dealCard(), this.dealCard(), this.dealCard())
        this.gameState.bettingRound = 'flop'
        break

      case 'flop':
        // Deal turn
        this.gameState.communityCards.push(this.dealCard())
        this.gameState.bettingRound = 'turn'
        break

      case 'turn':
        // Deal river
        this.gameState.communityCards.push(this.dealCard())
        this.gameState.bettingRound = 'river'
        break

      case 'river':
        // Showdown
        this.gameState.bettingRound = 'showdown'
        this.determineWinners()
        return
    }

    // Set first player to act (first active after dealer)
    let firstToAct = (this.gameState.dealerIndex + 1) % this.gameState.players.length
    while (this.gameState.players[firstToAct].hasFolded || this.gameState.players[firstToAct].chips === 0) {
      firstToAct = (firstToAct + 1) % this.gameState.players.length
    }
    this.gameState.currentPlayerIndex = firstToAct
  }

  private handleSidePots() {
    // Check if any players are all-in for less than the current bet
    const allInPlayers = this.gameState.players.filter(p => p.chips === 0 && p.currentBet > 0 && !p.hasFolded)
    
    if (allInPlayers.length === 0) return

    // Sort players by their current bet (ascending)
    const sortedPlayers = [...this.gameState.players]
      .filter(p => !p.hasFolded)
      .sort((a, b) => a.currentBet - b.currentBet)

    // Create side pots
    let previousBet = 0
    for (let i = 0; i < sortedPlayers.length; i++) {
      const player = sortedPlayers[i]
      const betDifference = player.currentBet - previousBet
      
      if (betDifference > 0) {
        // Players who can contribute to this side pot
        const eligiblePlayers = sortedPlayers
          .slice(i)
          .filter(p => p.currentBet >= player.currentBet)
          .map(p => p.id)

        if (eligiblePlayers.length > 1) {
          const sidePotAmount = betDifference * eligiblePlayers.length
          
          // Create side pot if it doesn't exist
          const existingSidePot = this.gameState.sidePots.find(pot => 
            pot.eligiblePlayers.length === eligiblePlayers.length &&
            pot.eligiblePlayers.every(id => eligiblePlayers.includes(id))
          )

          if (!existingSidePot) {
            this.gameState.sidePots.push({
              amount: sidePotAmount,
              eligiblePlayers
            })
          }
        }
        
        previousBet = player.currentBet
      }
    }
  }

  private determineWinners() {
    const activePlayers = this.gameState.players.filter(p => !p.hasFolded)
    
    if (activePlayers.length === 1) {
      // Only one player left, they win everything
      this.gameState.winners = [activePlayers[0].id]
      activePlayers[0].chips += this.gameState.pot
      this.gameState.isGameOver = true
      return
    }

    // Evaluate hands for all active players
    const playerHands = activePlayers.map(player => ({
      player,
      hand: this.evaluateHand([...player.cards, ...this.gameState.communityCards])
    }))

    // Sort by hand strength
    playerHands.sort((a, b) => this.compareHands(b.hand, a.hand))

    // Distribute main pot and side pots
    this.distributePots(playerHands)
    
    this.gameState.isGameOver = true
  }

  private distributePots(playerHands: any[]) {
    // Start with the main pot
    const potsToDistribute = [
      { amount: this.gameState.pot, eligiblePlayers: playerHands.map(ph => ph.player.id) },
      ...this.gameState.sidePots
    ]

    potsToDistribute.forEach(pot => {
      if (pot.amount <= 0) return

      // Find players eligible for this pot
      const eligibleHands = playerHands.filter(ph => pot.eligiblePlayers.includes(ph.player.id))
      
      if (eligibleHands.length === 0) return

      // Find best hand among eligible players
      const bestHand = eligibleHands[0].hand
      const winners = eligibleHands.filter(ph => this.compareHands(ph.hand, bestHand) === 0)

      // Split pot among winners
      const winAmount = Math.floor(pot.amount / winners.length)
      winners.forEach(winner => {
        winner.player.chips += winAmount
        if (!this.gameState.winners.includes(winner.player.id)) {
          this.gameState.winners.push(winner.player.id)
        }
      })
    })
  }

  private evaluateHand(cards: Card[]): {
    rank: number
    name: string
    cards: Card[]
  } {
    // Simplified hand evaluation - in a real implementation, this would be much more complex
    // For now, we'll return a basic evaluation
    
    const suits = cards.map(c => c.suit)
    const ranks = cards.map(c => c.value).sort((a, b) => b - a)
    
    const isFlush = suits.every(suit => suit === suits[0])
    const isStraight = this.isStraight(ranks)
    
    // Count rank occurrences
    const rankCounts: { [key: number]: number } = {}
    ranks.forEach(rank => {
      rankCounts[rank] = (rankCounts[rank] || 0) + 1
    })
    
    const counts = Object.values(rankCounts).sort((a, b) => b - a)
    
    if (isFlush && isStraight && ranks[0] === 14) {
      return { rank: 10, name: 'Royal Flush', cards }
    }
    if (isFlush && isStraight) {
      return { rank: 9, name: 'Straight Flush', cards }
    }
    if (counts[0] === 4) {
      return { rank: 8, name: 'Four of a Kind', cards }
    }
    if (counts[0] === 3 && counts[1] === 2) {
      return { rank: 7, name: 'Full House', cards }
    }
    if (isFlush) {
      return { rank: 6, name: 'Flush', cards }
    }
    if (isStraight) {
      return { rank: 5, name: 'Straight', cards }
    }
    if (counts[0] === 3) {
      return { rank: 4, name: 'Three of a Kind', cards }
    }
    if (counts[0] === 2 && counts[1] === 2) {
      return { rank: 3, name: 'Two Pair', cards }
    }
    if (counts[0] === 2) {
      return { rank: 2, name: 'One Pair', cards }
    }
    
    return { rank: 1, name: 'High Card', cards }
  }

  private isStraight(ranks: number[]): boolean {
    const uniqueRanks = [...new Set(ranks)].sort((a, b) => b - a)
    
    // Check for regular straight
    for (let i = 0; i <= uniqueRanks.length - 5; i++) {
      let isStraight = true
      for (let j = 0; j < 4; j++) {
        if (uniqueRanks[i + j] - uniqueRanks[i + j + 1] !== 1) {
          isStraight = false
          break
        }
      }
      if (isStraight) return true
    }
    
    // Check for A-2-3-4-5 straight
    if (uniqueRanks.includes(14) && uniqueRanks.includes(2) && 
        uniqueRanks.includes(3) && uniqueRanks.includes(4) && uniqueRanks.includes(5)) {
      return true
    }
    
    return false
  }

  private compareHands(hand1: any, hand2: any): number {
    if (hand1.rank !== hand2.rank) {
      return hand1.rank - hand2.rank
    }
    return 0 // Simplified - would need to compare kickers in real implementation
  }

  getGameState(): GameState {
    return { ...this.gameState }
  }

  // Helper method to convert Card to string representation
  static cardToString(card: Card): string {
    const suitSymbols = {
      hearts: 'h',
      diamonds: 'd',
      clubs: 'c',
      spades: 's'
    }
    return card.rank + suitSymbols[card.suit]
  }

  // Helper method to convert string to Card
  static stringToCard(cardStr: string): Card {
    const rank = cardStr.slice(0, -1)
    const suitSymbol = cardStr.slice(-1)
    
    const suitMap: { [key: string]: Card['suit'] } = {
      'h': 'hearts',
      'd': 'diamonds',
      'c': 'clubs',
      's': 'spades'
    }
    
    const rankValues: { [key: string]: number } = {
      '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10,
      'J': 11, 'Q': 12, 'K': 13, 'A': 14
    }
    
    return {
      suit: suitMap[suitSymbol],
      rank,
      value: rankValues[rank]
    }
  }
}