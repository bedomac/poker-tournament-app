import { Server } from 'socket.io'
import { PokerGame, Player, Card } from './poker-logic'

interface TournamentRoom {
  id: string
  name: string
  game: PokerGame
  players: Map<string, { socketId: string; player: Player }>
  maxPlayers: number
  isStarted: boolean
}

const tournamentRooms = new Map<string, TournamentRoom>()

export const setupSocket = (io: Server) => {
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id)

    // Create or join tournament room
    socket.on('join-tournament', (data: { roomId: string; playerName: string }) => {
      try {
        let room = tournamentRooms.get(data.roomId)
        
        // Create room if it doesn't exist
        if (!room) {
          const initialPlayers: Player[] = []
          const game = new PokerGame(initialPlayers)
          room = {
            id: data.roomId,
            name: `Tournament ${data.roomId}`,
            game,
            players: new Map(),
            maxPlayers: 9,
            isStarted: false
          }
          tournamentRooms.set(data.roomId, room)
        }

        // Check if room is full
        if (room.players.size >= room.maxPlayers) {
          socket.emit('join-error', { message: 'Tournament is full' })
          return
        }

        // Check if tournament already started
        if (room.isStarted) {
          socket.emit('join-error', { message: 'Tournament already started' })
          return
        }

        // Create new player
        const newPlayer: Player = {
          id: socket.id,
          name: data.playerName,
          chips: 1500,
          cards: [],
          isDealer: false,
          isSmallBlind: false,
          isBigBlind: false,
          isActive: false,
          hasFolded: false,
          hasActed: false,
          bet: 0,
          currentBet: 0
        }

        // Add player to room
        room.players.set(socket.id, { socketId: socket.id, player: newPlayer })
        socket.join(data.roomId)

        // Update game with new players
        const currentPlayers = Array.from(room.players.values()).map(p => p.player)
        room.game = new PokerGame(currentPlayers)

        // Send success response
        socket.emit('join-success', { 
          roomId: data.roomId, 
          playerId: socket.id,
          players: currentPlayers
        })

        // Notify all players in room
        io.to(data.roomId).emit('player-joined', { 
          player: newPlayer,
          players: currentPlayers
        })

        console.log(`Player ${data.playerName} joined tournament ${data.roomId}`)
      } catch (error) {
        console.error('Error joining tournament:', error)
        socket.emit('join-error', { message: 'Failed to join tournament' })
      }
    })

    // Leave tournament
    socket.on('leave-tournament', (data: { roomId: string }) => {
      try {
        const room = tournamentRooms.get(data.roomId)
        if (!room) return

        const playerData = room.players.get(socket.id)
        if (!playerData) return

        // Remove player from room
        room.players.delete(socket.id)
        socket.leave(data.roomId)

        // Update game
        const currentPlayers = Array.from(room.players.values()).map(p => p.player)
        if (currentPlayers.length > 0) {
          room.game = new PokerGame(currentPlayers)
        } else {
          // Remove room if empty
          tournamentRooms.delete(data.roomId)
          return
        }

        // Notify remaining players
        io.to(data.roomId).emit('player-left', { 
          playerId: socket.id,
          players: currentPlayers
        })

        socket.emit('leave-success')

        console.log(`Player ${playerData.player.name} left tournament ${data.roomId}`)
      } catch (error) {
        console.error('Error leaving tournament:', error)
      }
    })

    // Start tournament
    socket.on('start-tournament', (data: { roomId: string }) => {
      try {
        const room = tournamentRooms.get(data.roomId)
        if (!room) {
          socket.emit('start-error', { message: 'Tournament not found' })
          return
        }

        if (room.players.size < 2) {
          socket.emit('start-error', { message: 'Need at least 2 players to start' })
          return
        }

        if (room.isStarted) {
          socket.emit('start-error', { message: 'Tournament already started' })
          return
        }

        // Start the game
        room.game.startNewHand()
        room.isStarted = true

        // Get initial game state
        const gameState = room.game.getGameState()
        const playersForUI = gameState.players.map(player => ({
          ...player,
          cards: player.cards.map(card => PokerGame.cardToString(card))
        }))

        // Notify all players
        io.to(data.roomId).emit('tournament-started', {
          gameState: {
            ...gameState,
            players: playersForUI,
            communityCards: gameState.communityCards.map(card => PokerGame.cardToString(card))
          }
        })

        console.log(`Tournament ${data.roomId} started with ${room.players.size} players`)
      } catch (error) {
        console.error('Error starting tournament:', error)
        socket.emit('start-error', { message: 'Failed to start tournament' })
      }
    })

    // Player action
    socket.on('player-action', (data: { roomId: string; action: string; amount?: number }) => {
      try {
        const room = tournamentRooms.get(data.roomId)
        if (!room || !room.isStarted) return

        const playerData = room.players.get(socket.id)
        if (!playerData) return

        // Execute player action
        room.game.playerAction(socket.id, data.action as any, data.amount)

        // Get updated game state
        const gameState = room.game.getGameState()
        const playersForUI = gameState.players.map(player => ({
          ...player,
          cards: player.cards.map(card => PokerGame.cardToString(card))
        }))

        // Notify all players
        io.to(data.roomId).emit('game-state-updated', {
          gameState: {
            ...gameState,
            players: playersForUI,
            communityCards: gameState.communityCards.map(card => PokerGame.cardToString(card))
          }
        })

        // Check if hand is complete
        if (gameState.isGameOver) {
          io.to(data.roomId).emit('hand-complete', {
            winners: gameState.winners,
            gameState: {
              ...gameState,
              players: playersForUI,
              communityCards: gameState.communityCards.map(card => PokerGame.cardToString(card))
            }
          })
        }

        console.log(`Player ${playerData.player.name} action: ${data.action}`)
      } catch (error) {
        console.error('Error processing player action:', error)
        socket.emit('action-error', { message: 'Invalid action' })
      }
    })

    // Start new hand
    socket.on('start-new-hand', (data: { roomId: string }) => {
      try {
        const room = tournamentRooms.get(data.roomId)
        if (!room || !room.isStarted) return

        // Start new hand
        room.game.startNewHand()

        // Get updated game state
        const gameState = room.game.getGameState()
        const playersForUI = gameState.players.map(player => ({
          ...player,
          cards: player.cards.map(card => PokerGame.cardToString(card))
        }))

        // Notify all players
        io.to(data.roomId).emit('new-hand-started', {
          gameState: {
            ...gameState,
            players: playersForUI,
            communityCards: gameState.communityCards.map(card => PokerGame.cardToString(card))
          }
        })

        console.log(`New hand started in tournament ${data.roomId}`)
      } catch (error) {
        console.error('Error starting new hand:', error)
      }
    })

    // Get tournament list
    socket.on('get-tournaments', () => {
      try {
        const tournaments = Array.from(tournamentRooms.values()).map(room => ({
          id: room.id,
          name: room.name,
          players: room.players.size,
          maxPlayers: room.maxPlayers,
          isStarted: room.isStarted
        }))

        socket.emit('tournaments-list', { tournaments })
      } catch (error) {
        console.error('Error getting tournaments list:', error)
      }
    })

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id)
      
      // Remove player from all rooms
      for (const [roomId, room] of tournamentRooms.entries()) {
        if (room.players.has(socket.id)) {
          const playerData = room.players.get(socket.id)
          room.players.delete(socket.id)
          socket.leave(roomId)

          // Update game
          const currentPlayers = Array.from(room.players.values()).map(p => p.player)
          if (currentPlayers.length > 0) {
            room.game = new PokerGame(currentPlayers)
            
            // Notify remaining players
            io.to(roomId).emit('player-left', { 
              playerId: socket.id,
              players: currentPlayers
            })
          } else {
            // Remove room if empty
            tournamentRooms.delete(roomId)
          }

          console.log(`Player ${playerData?.player.name} disconnected from tournament ${roomId}`)
        }
      }
    })

    // Send welcome message
    socket.emit('message', {
      text: 'Welcome to Texas Hold\'em Poker Server!',
      senderId: 'system',
      timestamp: new Date().toISOString(),
    })
  })
}